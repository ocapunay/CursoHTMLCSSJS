function sumar(){
	var v1 = document.getElementById('txtval1').value;
	var v2 = document.getElementById('txtval2').value;
	var suma;
	suma = parseInt(v1) + parseInt(v2);
	console.log('La suma es: ' + suma);
	alert('La suma de los valores es ' + suma);
}