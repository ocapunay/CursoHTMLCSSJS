function saludo(){
	window.alert("Hola Mundo!");
	var boton = document.getElementById("btnenvio");
	boton.innerHTML = "Cambio de texto";
}